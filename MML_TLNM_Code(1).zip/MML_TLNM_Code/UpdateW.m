function W =UpdateW(W,Y,J,U,X,param,k,d)
manifold = euclideanfactory(d, k);
problem.M = manifold;
problem.cost = @(x) Wcost(x,Y,J,U,X,param);
problem.grad = @(x) Wgrad(x,Y,J,U,X,param);
options = param.tooloptions;
[x xcost info] = steepestdescent(problem,W,options);
W = x;
end

function proj =Wproj(W)
W(W<0) = 0;
proj = W;
end

function cost = Wcost(W,Y,J, U, X,param)
lambdaw = param.lambda5;
ee = exp(-W'*X);
EE = (ones(size(ee))-ee)./(ones(size(ee))+ee);
uee = exp(-U*EE);
UEE = (ones(size(uee))-uee)./(ones(size(uee))+uee);
cost = 0.5*norm(J.*(Y-UEE),'fro')^2+0.5*lambdaw*norm(W,'fro')^2;
end

function grad = Wgrad(W,Y,J,U,X,param)
lambdaw = param.lambda5;
eee = exp(-X'*W);
EEE = (ones(size(eee))-eee)./(ones(size(eee))+eee);
uee = exp(-EEE*U');
UEE = (ones(size(uee))-uee)./(ones(size(uee))+uee);
Jj = J'.*(Y'-UEE);
grad1 = X*((Jj.*uee)./(ones(size(uee))+uee)*U.*eee);
gg = (Jj.*uee)./(ones(size(uee))+uee);
grad2 = X*(((ones(size(eee))-eee).*eee.*(gg*U))./((ones(size(eee))+eee).*(ones(size(eee))+eee)));
grad3 = X*((((ones(size(uee))-uee).*Jj.*uee)./((ones(size(uee))+uee).*(ones(size(uee))+uee))*U.*eee)./(ones(size(eee))+eee));
ggg = ((ones(size(uee))-uee).*Jj.*uee)./((ones(size(uee))+uee).*(ones(size(uee))+uee));
grad4 = X*(((ones(size(eee))-eee).*eee.*(ggg*U))./((ones(size(eee))+eee).*(ones(size(eee))+eee)));
grad = grad1+grad2+grad3+grad4+2*lambdaw*W;
end
