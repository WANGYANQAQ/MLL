function [ U,W ] = Init_UW(J,Y,U,W,X,param)
[l,k] = size(U);
[d,k] = size(W);
obj_old = [];
last = 0;
for i=1:param.maxIter
    U= upu(U,J,Y,param,l,k,W,X) ;
    W = upw(W,Y,J,U,X,param,k,d);
        lambdaw = param.lambda5;
    lambdau = param.lambda4;
    ee = exp(-W'*X);
    EE = (ones(size(ee))-ee)./(ones(size(ee))+ee);
    uee = exp(-U*EE);
    UEE = (ones(size(uee))-uee)./(ones(size(uee))+uee);
    obj = 0.5*norm(J.*(Y-UEE),'fro')^2+0.5*lambdaw*norm(W,'fro')^2+0.5*lambdau*norm(U,'fro')^2;
    disp(obj);
    last = last + 1;
    obj_old = [obj_old;obj];   
    if last < 5
        continue;
    end
    stopnow = 1;
    for ii=1:3
        stopnow = stopnow & (abs(obj-obj_old(last-1-ii)) < 1e-3);
    end
    if stopnow
        break;
    end
end
end

function W =upw(W,Y,J,U,X,param,k,d)
manifold = euclideanfactory(d, k);
problem.M = manifold;
problem.cost = @(x) Wcost(x,Y,J,U,X,param);
problem.grad = @(x) Wgrad(x,Y,J,U,X,param);
options = param.tooloptions;
[x xcost info] = steepestdescent(problem,W,options);
W = x;
end

function U= upu(U,J,Y,param,l,k,W,X)
manifold = euclideanfactory(l, k);
problem.M = manifold;
problem.cost = @(x) Ucost(x,J,Y,param,W,X);
problem.grad = @(x) Ugrad(x,J,Y,param,W,X);
options = param.tooloptions;
[x xcost info] = steepestdescent(problem,U,options);
U = x;
end

function cost = Ucost(U,J,Y,param,W,X)
lambdau = param.lambda4;
ee = exp(-W'*X);
EE = (ones(size(ee))-ee)./(ones(size(ee))+ee);
uee = exp(-U*EE);
UEE = (ones(size(uee))-uee)./(ones(size(uee))+uee);
cost = 0.5*norm(J.*(Y-UEE),'fro')^2+0.5*lambdau*norm(U,'fro')^2;
end

function grad = Ugrad(U,J,Y,param,W,X)
lambdau = param.lambda4;
ee = exp(-W'*X);
eee = exp(-X'*W);
EE = (ones(size(ee))-ee)./(ones(size(ee))+ee);
EEE = (ones(size(eee))-eee)./(ones(size(eee))+eee);
uee = exp(-U*EE);
UEE = (ones(size(uee))-uee)./(ones(size(uee))+uee);
Jj = J.*(Y-UEE);
grad1 = (Jj.*uee)./((ones(size(uee))+uee))*EEE;
grad2 = (Jj.*uee.*(ones(size(uee))-uee))./((ones(size(uee))+uee).*(ones(size(uee))+uee))*EEE;
grad = grad1+grad2+2*lambdau*U;
end

function proj =Wproj(W)
W(W<0) = 0;
proj = W;
end

function cost = Wcost(W,Y,J, U, X,param)
lambdaw = param.lambda5;
ee = exp(-W'*X);
EE = (ones(size(ee))-ee)./(ones(size(ee))+ee);
uee = exp(-U*EE);
UEE = (ones(size(uee))-uee)./(ones(size(uee))+uee);
cost = 0.5*norm(J.*(Y-UEE),'fro')^2+0.5*lambdaw*norm(W,'fro')^2;

end

function grad = Wgrad(W,Y,J,U,X,param)
lambdaw = param.lambda5;
eee = exp(-X'*W);
EEE = (ones(size(eee))-eee)./(ones(size(eee))+eee);
uee = exp(-EEE*U');
UEE = (ones(size(uee))-uee)./(ones(size(uee))+uee);
Jj = J'.*(Y'-UEE);
grad1 = X*((Jj.*uee)./(ones(size(uee))+uee)*U.*eee);
gg = (Jj.*uee)./(ones(size(uee))+uee);
grad2 = X*(((ones(size(eee))-eee).*eee.*(gg*U))./((ones(size(eee))+eee).*(ones(size(eee))+eee)));
grad3 = X*((((ones(size(uee))-uee).*Jj.*uee)./((ones(size(uee))+uee).*(ones(size(uee))+uee))*U.*eee)./(ones(size(eee))+eee));
ggg = ((ones(size(uee))-uee).*Jj.*uee)./((ones(size(uee))+uee).*(ones(size(uee))+uee));
grad4 = X*(((ones(size(eee))-eee).*eee.*(ggg*U))./((ones(size(eee))+eee).*(ones(size(eee))+eee)));
grad = grad1+grad2+grad3+grad4+2*lambdaw*W;
end


