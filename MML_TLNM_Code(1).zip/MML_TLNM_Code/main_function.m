function [U,W,Obj] = main_function(J,Y, X,param)
[d,n] = size(X);
[l,~] = size(Y);
k = param.k;
W = ones(d,k);
U = ones(l,k);
o = sum(J(:));
param.lambda4 = param.lambda4*o/(l*k);
param.lambda5 = param.lambda5*o/(d*k);
tic;
[ U,W ] = Init_UW(J,Y,U,W,X,param); 
obj_old = [];
last = 0;
tic;
for i=1:param.maxIter
    disp(i);
    U = UpdateU(U,J,Y,param,l,k,W,X);
    W = UpdateW(W,Y,J,U,X,param,k,d);
    lambdaw = param.lambda5;
    lambdau = param.lambda4;
    ee = exp(-W'*X);
    EE = (ones(size(ee))-ee)./(ones(size(ee))+ee);
    uee = exp(-U*EE);
    UEE = (ones(size(uee))-uee)./(ones(size(uee))+uee);
    obj = norm(J.*(Y-UEE),'fro')^2+lambdaw*norm(W,'fro')^2+lambdau*norm(U,'fro')^2;
    disp(obj);
    last = last + 1;
    obj_old = [obj_old;obj];
    if last < 100
        continue;
    end
    stopnow = 1;
    for ii=1:3
        stopnow = stopnow & (abs(obj-obj_old(last-1-ii)) < 1e-8);
    end
    if stopnow
        break;
    end
end

Obj = obj_old;
end

