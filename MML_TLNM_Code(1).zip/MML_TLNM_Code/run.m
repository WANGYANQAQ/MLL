function [ meanResult,time ] = run( )

param = importdata('the_param.mat');
data = load('the_sample.mat');
results=zeros(90,6);
h1=1:3:88;h2=2:3:89;h3=3:3:90;
for h=1:30
    dataset=data.data; targetset=data.target;
    p = randperm(size(dataset,1), 0.6*size(dataset,1));
    q=setdiff([1:size(dataset,1)],p);
    Xtrn=dataset(p,:); Ytrn=targetset(p,:)';
    Xtst=dataset(q,:); Ytst=targetset(q,:)';
    Ytrn(Ytrn==0)=-1; 
    Xtrn = Xtrn';
    Xtst = Xtst';
    Ytst(Ytst==0)=-1; 
    Result = []; time=[];
    for j=3:2:7
        s = RandStream.create('mt19937ar','seed',1);
        RandStream.setGlobalStream(s);
        tic;
        [J] = Select( Ytrn, 0.1*j);
        [U,W,Obj] = main_function(J,Ytrn, Xtrn,param);
        zz = mean(Ytst);
        Ytst(:,zz==-1) = [];
        Xtst(:,zz==-1) = [];
        ee = exp(-W'*Xtst);
        EE = (ones(size(ee))-ee)./(ones(size(ee))+ee);
        uee = exp(-U*EE);
        WWW = (ones(size(uee))-uee)./(ones(size(uee))+uee);
        ret =  evalt(WWW,Ytst, (max(WWW(:))-min(WWW(:)))/2);
        Re = [ret.RankingLoss;ret.AvgAuc;ret.Coverage;ret.AveragePrecision;ret.macrof1;ret.microf1];
        T=toc;
        
        
        Result = [Result,Re];
        time=[time;T];
    end
    Result = round(Result*10000)*0.0001;
    Result=Result';
    results( [h*3-2:h*3],:)=Result;
end
mean1=mean(results(h1,:));mean2=mean(results(h2,:));mean3=mean(results(h3,:));
meanResult=[mean1;mean2;mean3];

end


function stopnow = mystopfun(problem, x, info, last)
if last < 5
    stopnow = 0;
    return;
end
flag = 1;
for i = 1:3
    flag = flag & abs(info(last-i).cost-info(last-i-1).cost) < 1e-4;
end
stopnow = flag;
end