clc;
addpath('clf');
addpath('lib');
addpath(genpath('lib/manopt'));
addpath('evl');
 

[ Result ] =run()

