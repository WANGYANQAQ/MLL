function U= UpdateU(U,J,Y,param,l,k,W,X)
manifold = euclideanfactory(l, k);
problem.M = manifold;
problem.cost = @(x) Ucost(x,J,Y,param,W,X);
problem.grad = @(x) Ugrad(x,J,Y,param,W,X);
options = param.tooloptions;
[x xcost info] = steepestdescent(problem,U,options);
U = x;
end

function cost = Ucost(U,J,Y,param,W,X)
lambdau = param.lambda4;
ee = exp(-W'*X);
EE = (ones(size(ee))-ee)./(ones(size(ee))+ee);
uee = exp(-U*EE);
UEE = (ones(size(uee))-uee)./(ones(size(uee))+uee);
cost = 0.5*norm(J.*(Y-UEE),'fro')^2+0.5*lambdau*norm(U,'fro')^2;
end

function grad = Ugrad(U,J,Y,param,W,X)
lambdau = param.lambda4;
ee = exp(-W'*X);
eee = exp(-X'*W);
EE = (ones(size(ee))-ee)./(ones(size(ee))+ee);
EEE = (ones(size(eee))-eee)./(ones(size(eee))+eee);
uee = exp(-U*EE);
UEE = (ones(size(uee))-uee)./(ones(size(uee))+uee);
Jj = J.*(Y-UEE);
grad1 = (Jj.*uee)./((ones(size(uee))+uee))*EEE;
grad2 = (Jj.*uee.*(ones(size(uee))-uee))./((ones(size(uee))+uee).*(ones(size(uee))+uee))*EEE;
grad = grad1+grad2+2*lambdau*U;
end


