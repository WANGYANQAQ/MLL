function [J] = Select( data, ratio )

if ratio == 1
         J = ones(size(data));
         return;
     end
     J = zeros(size(data));
     for i=1:size(data,1)
         y = data(i,:);
         pos = find(y==1);
         neg = find(y~=1);
         pi = randperm(length(pos));
         pi = pi(1:ceil(ratio*length(pos)));
         J(i,pos(pi)) = 1;
         ni = randperm(length(neg));
         ni = ni(1:ceil(ratio*length(neg)));
         J(i,neg(ni)) = 1;
     end
end

